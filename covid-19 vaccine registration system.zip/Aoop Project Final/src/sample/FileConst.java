package sample;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class FileConst{
    int i = 0;

    public ArrayList<String[]> al = new ArrayList<String[]>();
    public String[] x = new String[15];

    public void writeEverything(){

//        try {
//            FileWriter fw = new FileWriter("adminInfo.txt", true);
//            BufferedWriter bw = new BufferedWriter(fw);
//
//            bw.write("Admin #" +(al.size()));
//            bw.newLine();
//            bw.newLine();
//            bw.write("First Name: " + al.get(i)[0]);
//            bw.newLine();
//            bw.write("Last Name: " + al.get(i)[1]);
//            bw.newLine();
//            bw.write("Present Address: " + al.get(i)[2]);
//            bw.newLine();
//            bw.write("Permanent Address: " + al.get(i)[3]);
//            bw.newLine();
//            bw.write("Postal Code: " + al.get(i)[4]);
//            bw.newLine();
//            bw.write("Phone: " + al.get(i)[5]);
//            bw.newLine();
//            bw.write("NID: " + al.get(i)[6]);
//            bw.newLine();
//            bw.write("Email: " + al.get(i)[7]);
//            bw.newLine();
//            bw.write("Occupation: " + al.get(i)[8]);
//            bw.newLine();
//            bw.write("Gender: " + al.get(i)[9]);
//            bw.newLine();
//            bw.write("Date Of Birth: " + al.get(i)[10]);
//            bw.newLine();
//            bw.write("Vaccinated: " + al.get(i)[11]);
//            bw.newLine();
//            bw.write("Medical Condition: " + al.get(i)[12]);
//            bw.newLine();
//            bw.write("Work Experience: " + al.get(i)[13]);
//            bw.newLine();
//            bw.write("Reference: " + al.get(i)[14]);
//            bw.newLine();
//            bw.write("Password: " + al.get(i)[15]);
//            bw.newLine();
//            bw.newLine();
//
//
//            bw.close();
//            fw.close();
//        } catch (IOException ioException) {
//            ioException.printStackTrace();
//        }
//
    }

}
